#!/usr/bin/perl

## This perl script is designed to run the Fuzzy K-means cluster/pattern finding program used in Brady et al., Science 2007
## Its main function is to interactivley have the user set the necessary parameters/settings and then
## the program generates the appropriate R-script and cluster submission script and submits the job
## to the sun-grid cluster, or just produces the R-file for the user to run themselves

use strict;

##print welcome and header/intro information
print "\n--- Welcome to the Fuzzy K-means / Pattern finding Program ----\n";
print "This program will ask you to set a number of variables used in the program\n";
print "and will then give you the option of submitting automatically to the cluster, or generate an R-file which can be run by the command given at the end";
print "\n\nThe program works by printing a series of questions in the form of:\n\t";
print "What is your favorite color: [RED,BLUE,GREEN] <RED> : \n";
print "The possible choices will be listed in the square [] brackets and the default option will be listed in the angle <> brackets (if \"<>\", then there is no default).\n";
print "Type in your choice exactly as it appears and then hit enter. \nIf you dont type anything and hit enter, the default choice will be used.\nThe program will try and detect bad responses and prompt you to retry.\nTo force it to accept an answer just put \"!\" in front of the response. \nTo quit at anytime type \"QUIT\".\n\n\n";


#Start program

my $ans = askQuestion("Ready to begin:",["YES","NO"],"NO");
if($ans eq "NO"){
	print "\n\tOkay. Bye!\n";
	die();
}else{
	print "------------------------------------------------------\n";	
	print "---------------Starting Program----------------------\n\n";	
}

my $inputFile = askQuestion("Input File Name:",["Any Text"],"");
my $prefix = askQuestion("Output file prefix name:",["Any Text"],"");
my $minExpFilter = askQuestion("Minimum Exp Filter:",["Any positive number, or FALSE"],"FALSE");
my $minVarFilter = askQuestion("Minimum Variance Filter:",["Any positive integer, or FALSE"],"FALSE");
my $kChoice = askQuestion("K-Choice",["Any positive integer"],"");
my $fuzzyKMemb = askQuestion("Fuzzy K Membership Exp:",["Any positive number"],"1.04");
my $log2 = askQuestion("Is data already log2 transformed:",["TRUE","FALSE"],"TRUE");

my $saveClust = askQuestion("Save Clustering object (LARGE):",["TRUE","FALSE"],"FALSE");
my $saveDist = askQuestion("Save Distance object (LARGE):",["TRUE","FALSE"],"FALSE");
my $saveExp = askQuestion("Save Complete Expression data:",["TRUE","FALSE"],"FALSE");
my $saveFunc = askQuestion("Save R functions:",["TRUE","FALSE"],"FALSE");
my $saveParam = askQuestion("Save all R params:",["TRUE","FALSE"],"FALSE");

my $autoCutoff = askQuestion("Automatically select cluster cutoff:",["TRUE","FALSE"],"TRUE");
my $clustCutoff = 0.4;
if($autoCutoff eq "FALSE"){
	$clustCutoff = askQuestion("Cluster cutoff value:",["Any positive number (between 0-1)"],"0.4");
}
my $patternCutoff = askQuestion("Pattern Similiarty Cutoff (used to be 1-R, now is R):",["Any positive number (between 0-1)"],"0.9");
my $pearsonCutoff = askQuestion("Pearson Correlation Cutoff:",["Any positive number (between 0-1)"],"0.85");
my $userInputFile = askQuestion("Do you have a pre-set pattern file:",["TRUE","FALSE"],"FALSE");
if($userInputFile eq "TRUE"){
	$userInputFile = askQuestion("User pattern file-name:",["Any Text"],"");
}

my $userRFile = generateRScript($inputFile,$minExpFilter,$minVarFilter,$kChoice,$fuzzyKMemb,$log2,$prefix,$saveClust,$saveDist,$saveExp,$saveFunc,$saveParam,$autoCutoff,$clustCutoff,$patternCutoff,$pearsonCutoff,$userInputFile);
open(FOUT,"> ".$prefix."_PatternFind_Rcode.r");
print FOUT $userRFile;
close(FOUT);


$ans = askQuestion("Will you run this job on a cluster:",["YES","NO"],"YES");
if($ans eq "NO"){
	print "\nOkay! We are done. Successfully created \"$prefix"."_PatternFind_Rcode.r\" for you to use.\n\n";
	print "To run the pattern finding program simply put the \"$inputFile\" \nand R-code file \"$prefix"."_PatternFind_Rcode.r\" in the same folder.\n";
	print "\nOpen R and change working directory to that folder.\n";
	print "Type: \"source(\"$prefix"."_PatternFind_Rcode.r\")\"  and hit enter.\n";
	print "\nAnd thats it. R will run your custom clustering and store the results in the same folder.\n";
	print "\t Goodbye!\n\n";
}else{
	my $runAuto = askQuestion("Should this program submit the job automatically:",["YES","NO"],"YES");
	my $workDir = `pwd`;
	if($runAuto eq "NO"){
		print "\tOkay. We will just set up the file and you can submit it.\n";
		$workDir = askQuestion("Data file will be in folder:",["Any Text"],$workDir);
	}else{
		$ans = askQuestion("\tOkay. But, is the data file, \"$inputFile\", in this folder:",["YES","NO"],"YES");
		if($ans eq "NO"){
			print "I'm sorry. But the script will behave badly. Please move the input file to this folder and re-run the script.\n\tSorry.\n";
			die();
		}
	}
	my $options = "";
	$ans = askQuestion("Would you like to be emailed status updates:",["YES","NO"],"YES");
	if($ans eq "YES"){
		$ans = askQuestion("Email Address",["Any Text"],"");
		$options = $options.'#$ -M '.$ans."\n".'#$ -m ';
		$ans = askQuestion("Notify on Start",["YES","NO"],"YES");
		if($ans eq "YES"){$options = $options."b";}
		$options = $options."e";
		$ans = askQuestion("Notify on Abort",["YES","NO"],"YES");
		if($ans eq "YES"){$options = $options."a";}
	}
	$ans = askQuestion("Would you like to set memory requirements:",["YES","NO"],"YES");
	if($ans eq "YES"){
		$ans = askQuestion("Require how much memory (in gigabytes)",["Any positive number"],"2.0");
		$options = $options."\n".'#$ -l mem_free='.$ans."G\n";
	}
	$ans = askQuestion("Run as high-priority (limits possible nodes):",["YES","NO"],"NO");
	if($ans eq "YES"){
		$options = $options."\n".'#$ -l highprio'."\n";
	}
	open(FOUT,"> ".$prefix."_jobSubmit.q");
	print FOUT generateQFile($prefix,$workDir,$options);
	close(FOUT);
	if($runAuto eq "YES"){
		system("qsub ".$prefix."_jobSubmit.q");
		print "\nJob submitted!!\nYou are all done!\n";
	}else{
		print "\n\nOkay. We are done. \n The job submission file is \"".$prefix."_jobSubmit.q\"\nJust move the job submission file and the R-script, \"$prefix"."_PatternFind_Rcode.r\" into the folder, \"$workDir\".";
		print "\nThen go to that folder and type: \"qsub ".$prefix."_jobSubmit.q;\".\n";
		print "\t Goodbye!\n\n";
	}
}



sub askQuestion {
	my ($questionText,$array_ref,$defaultVal) = @_;
	my @possibleVals = @{$array_ref};
	print $questionText." [".join(",",@possibleVals),"] <".$defaultVal."> : ";
	my $result = <>;
	$result =~ s/\n$//;
	if($result =~ m/^\!*QUIT$/){
		print "\n\nUSER QUIT REQUEST. Goodbye.\n";
		die();
	}
	#Check to see if there is a valid default and if so, return
	if(($result eq "") & ($defaultVal ne "")){
		return($defaultVal);
	}

	if(($result eq $defaultVal) & ($defaultVal ne "")){  #Check that the user may have typed the default value and return fast
		return($result);
	}

	if($result =~ m/^!/){  #FORCE USAGE. BAD IDEA
		$result =~ s/^!//;
		print "\tUser is forcing usage of \"$result\". This may be unstable.\n";
		return($result);
	}

	my $validResponse=0;
	if(scalar(@possibleVals)>1){  #Are set choices
		foreach my $goodVal(@possibleVals){
			if($result eq $goodVal){
				$validResponse=1;
			}
		}
	}else{   #must be on the following types
		if($possibleVals[0] =~ m/^Any Text/){
			if($result ne ""){   #As long as there is something
				$validResponse=1;
			}
		}
		if($possibleVals[0] =~ m/^Any positive number/){
			if(($result =~ /^[0-9]+\.*[0-9]*$/) & ($result !~ /^[\. ]*$/)){
				$validResponse=1;
			}
		}
		if($possibleVals[0] =~ m/^Any positive integer/){
			if($result =~ m/^\d+$/){   #As long as there is something
				$validResponse=1;
			}
		}
	}
	if($validResponse==0){
		print "\tI'm sorry, but \"$result\" is not a valid choice for this question. Please try again.\n\n";
		$result = askQuestion($questionText,$array_ref,$defaultVal);
	}
	return($result);
}


sub generateRScript {
my ($inputFile,$minExpFilter,$minVarFilter,$kChoice,$fuzzyKMemb,$log2,$prefixName,$saveClust,$saveDist,$saveExp,$saveFunc,$saveParam,$autoSelect,$clustCut,$patternCut,$pearsonCut,$userPatternFile) = @_;

my $Rscript = '
##-------------- Parameters for first step - fuzzy K-means clustering
##--------------------------------------------------------------------

inputFile <- "'.$inputFile.'"
minExpFilter <- '.$minExpFilter.' #FALSE OR 1
minVarFilter <- '.$minVarFilter.' #FALSE OR 50
kChoice <- '.$kChoice.' #20
fuzzyKmemb <- '.$fuzzyKMemb.' #1.05
alreadyLog2 <- '.$log2.' #TRUE
methodResultFile <- "'.$prefixName.'_patternIdent_result.rDump"
diagnosticFile <- "'.$prefixName.'_clustering_diagnostic.txt"


##---------This controls how much data is in the final R object
##--------------------------------------------------------------------
saveRawClusterObject <- '.$saveClust.' #FALSE, if TRUE the file will be large
saveClusterDistanceMat <- '.$saveDist.' #FALSE, if TRUE the file will be large
saveCompleteExpData <- '.$saveExp.' #FALSE
saveFunctions <- '.$saveFunc.' #FALSE
saveParamVariables <- '.$saveParam.' #FALSE

##-------------- Parameters for 2nd step - building patterns
##--------------------------------------------------------------------

autoSelectClusterCutoff <- '.$autoSelect.' #TRUE
clusterCutoff <- '.$clustCut.' #0.4
patternSimilarityCutoff <- '.$patternCut.' #0.9
pearsonCutoff <- '.$pearsonCut.' #0.85

userPatternInputFile <- '.$userPatternFile.' #FALSE
patternOutputFile <- "'.$prefixName.'_patternOutput.txt"
groupOutputFile <- "'.$prefixName.'_genesToPatterns.txt"
diagnosticFile <- "'.$prefixName.'_patternIdent_diagnostic.txt"

#-------------------------------------------------
#-------------------------------------------------

library(cluster)
removeLowE <- 0
removeLowV <- 0
dateRun<- date()
cat("Starting Fuzzy K-Means clustering on ",dateRun,"\n",file=diagnosticFile)
expressionData <-read.table(file=inputFile,sep="\t",header=TRUE)
expressionData <- as.matrix(expressionData)
cat("Expression data read from ",inputFile,"\n",file=diagnosticFile,append=TRUE)
cat("\t",nrow(expressionData)," genes with ",ncol(expressionData)," observations.\n",file=diagnosticFile,append=TRUE)
expDataFiltered <- expressionData
filterSettings <- paste("Filter Settings:\n\tInput File = ",inputFile,sep="")

#-------------------------------------------------
#-------------------------------------------------

cat("Removing low expressed genes - ",file=diagnosticFile,append=TRUE)
filterSettings <- paste(filterSettings,"\n\tLow Expression Filter = ",sep="")
if(is.numeric(minExpFilter)){
	keep <- c(1:nrow(expDataFiltered))[apply(expDataFiltered,1,max)>=minExpFilter]
	removeLowE <- nrow(expDataFiltered)-length(keep)
	expDataFiltered <- expDataFiltered[keep,]
	cat("Done\n",file=diagnosticFile,append=TRUE)
	filterSettings <- paste(filterSettings,minExpFilter," (",removeLowE," genes removed)\n",sep="")
}else{
	cat("Skipped\n",file=diagnosticFile,append=TRUE)
	filterSettings <- paste(filterSettings,"FALSE\n",sep="")
}

#-------------------------------------------------
#-------------------------------------------------

cat("Removing low varying genes - ",file=diagnosticFile,append=TRUE)
filterSettings <- paste(filterSettings,"\tLow Variance Filter = ",sep="")
if(is.numeric(minVarFilter)){
	lowVarCut <- quantile(apply(expDataFiltered,1,var),probs=(minVarFilter/100))
	keep <- c(1:nrow(expDataFiltered))[apply(expDataFiltered,1,var)>=lowVarCut]
	removeLowV <- nrow(expDataFiltered)-length(keep)
	expDataFiltered <- expDataFiltered[keep,]
	cat("Done\n",file=diagnosticFile,append=TRUE)
	filterSettings <- paste(filterSettings,minVarFilter,"% (",removeLowV," genes removed)\n",sep="")
}else{
	cat("Skipped\n",file=diagnosticFile,append=TRUE)
	filterSettings <- paste(filterSettings,"FALSE\n",sep="")
}
cat(filterSettings,file=diagnosticFile,append=TRUE)

#-------------------------------------------------
#-------------------------------------------------

cat("Log2 Transforming expression data - ",file=diagnosticFile,append=TRUE)
if(!alreadyLog2){
    expDataFiltered[expDataFiltered==0] <- 1e-10
    expDataFiltered <- log2(expDataFiltered/apply(expDataFiltered,1,mean))
    expressionData[expressionData==0] <- 1e-10
    expressionData <- log2(expressionData/apply(expressionData,1,mean))
    cat("Done\n",file=diagnosticFile,append=TRUE)
}else{
    cat("Skipped\n",file=diagnosticFile,append=TRUE)
}

#-------------------------------------------------
#-------------------------------------------------

cat("Building distance matrix for clustering - ",file=diagnosticFile,append=TRUE)
distanceMat<-as.dist((1-cor(t(expDataFiltered),method="pearson"))/2)
cat(" Done\n",file=diagnosticFile,append=TRUE)

fuzzyKSettings <- paste("Fuzzy K-Means settings:\n\tK = ",kChoice,"\n\tmemb.exp = ",fuzzyKmemb,sep="")
fuzzyKSettings <- paste(fuzzyKSettings,"\n\tmaxit = ",(nrow(expDataFiltered)*4),"\n",sep="")

cat("Running fuzzy K-means to produce ",kChoice," clusters from ",nrow(expDataFiltered)," genes.\n",file=diagnosticFile,append=TRUE)
cat(fuzzyKSettings,file=diagnosticFile,append=TRUE)
cat("\n!!! This may take a long time to complete. !!!\n",file=diagnosticFile,append=TRUE)

initClust <- fanny(distanceMat, kChoice, diss = TRUE, memb.exp= fuzzyKmemb,maxit=nrow(expDataFiltered)*4)
cat("Done clustering!\nSaving results to ",methodResultFile,"\n",file=diagnosticFile,append=TRUE)

saveList <- c("expDataFiltered","filterSettings","fuzzyKSettings","dateRun")
if(saveRawClusterObject){
	saveList <- c("initClust",saveList)
}
if(saveClusterDistanceMat){
	saveList <- c("distanceMat",saveList)
}else{
	rm("distanceMat")
}
if(saveCompleteExpData){
	saveList <- c("expressionData",saveList)
}else{
	rm("expressionData")
}

save(file=methodResultFile,list=saveList)
cat("Done. Initial clustering completed.\n\n",file=diagnosticFile,append=TRUE)


#-----------------Functions used by pattern collapse and assignment code -------------
#-------------------------------------------------------------------------------------
getClustProfiles <- function(expDataIn,clustIn,clusterCutoff){
    numClusters <- ncol(clustIn$membership)
    clustProfiles <- matrix(data=0,ncol=ncol(expDataIn),nrow=numClusters)
    for(i in 1:numClusters){
        genesInClust <- c(1:nrow(expDataIn))[clustIn$membership[,i]>=clusterCutoff]
        if(length(genesInClust)>0){
                    if(length(genesInClust)>1){
                             clustProfiles[i,]<-as.numeric(apply(expDataIn[genesInClust,],2,median))
                    }else{
                                clustProfiles[i,]<-as.numeric(expDataIn[genesInClust,])
                    }
        }
    }
    whichCluster <- c(1:numClusters)[apply(clustProfiles,1,var)>0]
    clustProfiles <- clustProfiles[apply(clustProfiles,1,var)>0,]
    return(list(profiles=clustProfiles,whichClust=whichCluster))
}


makeCollapsedProfiles <- function(expDataIn,clustProfsIn, clusterCutoff,grouping,origClust,clustIn){
    collapsedProfiles <- matrix(data=0,ncol=ncol(expDataIn),nrow=max(grouping))
    for(i in 1:max(grouping)){
        inClust <- c(1:length(grouping))[grouping==i]
        if(length(inClust)==1){
            collapsedProfiles[i,]<-clustProfsIn[inClust,]
            genesInClust <- c(1:nrow(expDataIn))[clustIn$membership[,origClust[inClust]]>=0.4]
        }else{
            cat("\tCollapsing profiles ",paste(inClust,collapse=","),"into new profile ",i,"\n")
            clustLookAt <- origClust[inClust]
            genesInClust <- c(1:nrow(expDataIn))[apply(clustIn$membership[,clustLookAt],1,max)>= clusterCutoff]
            collapsedProfiles[i,]<-apply(expDataIn[genesInClust,],2,median)
        }
    }
return(collapsedProfiles)
}

correlateGenesToProfiles <- function(expDataIn,profilesIn){
    profileCor <- matrix(data=0,ncol=nrow(profilesIn),nrow=nrow(expDataIn))
    for(i in 1:nrow(profilesIn)){
        profileCor[,i] <- apply(expDataIn,1,cor,y=profilesIn[i,])
        cat("\tCorrelating genes to profile ",i," out of ",nrow(profilesIn),"\n")
    }
    rownames(profileCor)<-rownames(expDataIn)
    colnames(profileCor)<-rownames(profilesIn)
    return(profileCor)
}


writeMemberList <- function(patternCor,minDist,fileOut){
    maxSize <- max(apply(patternCor>=minDist,2,sum))
    tempMat <- matrix(data="",ncol=ncol(patternCor),nrow=maxSize)
    colnames(tempMat)<-colnames(patternCor)
    for(i in 1:ncol(tempMat)){
        geneList <- rownames(patternCor)[patternCor[,i]>=minDist]
        if(length(geneList)>0){
                tempMat[1:length(geneList),i]<-geneList
        }
    }
    write.table(file=fileOut,tempMat,sep="\t",quote=FALSE,row.names=FALSE,col.names=colnames(tempMat))
}

#-----------------------------------------------------------------------------------------------------
#-----------------Start of executed code-------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------

#-----------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------

cat("Starting Pattern Identification & Gene Assignment\n",file=diagnosticFile)
load(methodResultFile)
if(autoSelectClusterCutoff){
    clusterCutoff <- initClust$membership[sort(initClust$membership,index.return=TRUE,decreasing=TRUE)$ix[nrow(initClust$membership)]]
}
cantAssignGenes<-(apply(initClust$membership,1,max)<clusterCutoff)
goodGenes<-(apply(initClust$membership,1,max)>=clusterCutoff)
initClust$cluster[cantAssignGenes]<-0
initClust$membership[cantAssignGenes,]<-0
cat("Number of genes assigned to a cluster above ",clusterCutoff," =",file=diagnosticFile,append=TRUE)
cat(sum(goodGenes),"/",length(initClust$cluster),"\n",file=diagnosticFile,append=TRUE)
cat("Number of genes not assigned to a cluster above ",clusterCutoff," =",file=diagnosticFile,append=TRUE)
cat(sum(cantAssignGenes),"/",length(initClust$cluster),"\n",file=diagnosticFile,append=TRUE)
cat("Generating inital set of patterns.\n",file=diagnosticFile,append=TRUE)
clustProfiles <- getClustProfiles(expDataFiltered,initClust,clusterCutoff)
whichClusters <- clustProfiles$whichClust
clustProfiles <- clustProfiles$profiles

#-----------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------

cat("Calculating distances between each pattern.\n",file=diagnosticFile,append=TRUE)
profileCor <- cor(t(clustProfiles))
diag(profileCor)<-NA
hClust <- hclust(as.dist(1-profileCor),method="single")
collapseGrp <- cutree(hClust,h=(1-patternSimilarityCutoff))

cat("Collapsing similar patterns.\n",file=diagnosticFile,append=TRUE)
finalProfiles<-makeCollapsedProfiles(expDataFiltered,clustProfiles, clusterCutoff ,collapseGrp,whichClusters,initClust)
rownames(finalProfiles)<- paste("Pattern_",1:nrow(finalProfiles),sep="")
colnames(finalProfiles)<-colnames(expDataFiltered)
colnames(finalProfiles)[1] <- paste("\t",colnames(finalProfiles)[1],sep="")
if(is.character(userPatternInputFile)){
	cat("Adding user defined patterns from \"",userPatternInputFile,"\".\n",file=diagnosticFile,append=TRUE)
	userPatterns <- read.delim(file=userPatternInputFile,sep="\t",header=TRUE)
	tempFinal <- matrix(data=0,ncol=ncol(finalProfiles),nrow=nrow(finalProfiles)+nrow(userPatterns))
	tempFinal[1:nrow(finalProfiles),]<-finalProfiles
	tempFinal[(nrow(finalProfiles)+1):nrow(tempFinal),]<-as.matrix(userPatterns[,2:ncol(userPatterns)])
	rownames(tempFinal) <- c(rownames(finalProfiles),userPatterns[,1])
	colnames(tempFinal) <- colnames(finalProfiles)
	finalProfiles <- tempFinal
}
cat("Writing patterns to output file.\n",file=diagnosticFile,append=TRUE)
write.table(file=patternOutputFile,finalProfiles,quote=FALSE,sep="\t")

#-----------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------

cat("Assigning genes to patterns.\n",file=diagnosticFile,append=TRUE)
geneToPatternCor <- correlateGenesToProfiles(expDataFiltered,finalProfiles)

cat("Writing gene to pattern output file.\n",file=diagnosticFile,append=TRUE)
writeMemberList(geneToPatternCor,pearsonCutoff,groupOutputFile)
cat("Pattern Identification and Gene Assignment completed.\n",file=diagnosticFile,append=TRUE)



if(!saveRawClusterObject){
	rm("initClust")
}
removeVarList <- c("cantAssignGenes","goodGenes","profileCor","hClust","collapseGrp","clustProfiles","removeVarList","removeFunctionList","inputFile","minExpFilter","minVarFilter","fuzzyKmemb","alreadyLog2","diagnosticFile","saveRawClusterObject","saveClusterDistanceMat","saveCompleteExpData","saveFunctions","saveParamVariables","autoSelectClusterCutoff","userPatternInputFile","patternOutputFile","groupOutputFile","removeLowE","removeLowV","kChoice","whichClusters")
removeFunctionList <- c("getClustProfiles","makeCollapsedProfiles","writeMemberList","correlateGenesToProfiles")
if(!saveParamVariables){
	rm(list=removeFunctionList)
}
if(!saveFunctions){
	rm(list=removeVarList)
}

save(file=methodResultFile,list=ls())



##This little snippet just checks to see if its possible to draw images on the current machine
##this is only really a problem on cluster machines
gsexe <- Sys.getenv("R_GSCMD")
if(is.null(gsexe) || !nchar(gsexe)) {
        gsexe <- "gs"
        rc <- system(paste(gsexe, "-help > /dev/null"))
        if(rc != 0){q("no")} #We cant make images. quit and end program
}






#--------------------------------------------------------------------------------------------
#----This code snippet will draw the heatmaps and line graphs for the patterns & genes-------
#--------------------------------------------------------------------------------------------
#--Change the numbers inside par(mar=c(x,x,x,x)) to adjust margin size on bottom,left,top,right---
#---in case the axis labels do not print, just make the appropriate axis margin larger ---

drawGeneGroupCurves <- function(inputData,title="",xAxisNames=colnames(inputData),centerCurve=ifelse(nrow(inputData)>1,apply(inputData,2,median),inputData)){
	yRng <- max(abs(c(inputData,centerCurve)))
	yRng <- c(-yRng,yRng)
	matplot(1:ncol(inputData),t(inputData),ylim=yRng,xaxt="n",ylab="Expression",main=title,xlab="",type="l",lwd=0.5,col=8,lty=1)
	lines(1:ncol(inputData),centerCurve,col=1,lwd=2)
	if(!is.na(xAxisNames[1])){
		axis(1,1:ncol(inputData),xAxisNames,las=2)
	}
}

drawExpressionHeatmap <- function(inputData,title="",yAxisNames=rownames(inputData),xAxisNames=colnames(inputData),autoOrder=TRUE,maxExp=2,minExp=-2,standAlone=TRUE){
	cols <- c(rgb(0,49:0/49,49:0/49),rgb(1:50/50,1:50/50,0))
	if(autoOrder & nrow(inputData)>2){
		newOrd <- hclust(dist(inputData))$order
		inputData <- inputData[newOrd,]
		yAxisNames <- yAxisNames[newOrd]
	}
	brks <- seq(minExp,maxExp,length=101)
	if(standAlone){
		nf <- layout(matrix(data=c(1,1,1,1,2),nrow=1))
	}
	inputData[inputData>maxExp]<-maxExp
	inputData[inputData<minExp]<-minExp
	image(1:ncol(inputData),1:nrow(inputData),t(inputData),xaxt="n",yaxt="n",xlab="",ylab="",main=title,breaks=brks,col=cols)
	if(!is.na(xAxisNames[1])){
		axis(1,1:ncol(inputData),xAxisNames,las=2)
	}
	if(!is.na(yAxisNames[1])){
		axis(2,1:nrow(inputData),yAxisNames,las=2)
	}
	if(standAlone){
		tempMat <- matrix(data=seq(minExp,maxExp,length=100),ncol=2,nrow=100)
		image(1:2,seq(minExp,maxExp,length=100),t(tempMat),breaks=brks,col=cols,xaxt="n",xlab="",ylab="",main="Key")
	}
}


load(file="'.$prefixName.'_patternIdent_result.rDump")
bitmap(file="'.$prefixName.'_profileHeatmap.png",type="png16m",height=4,width=6,res=200)
par(mar=c(11,7,2,1))
drawExpressionHeatmap(finalProfiles,title="Patterns")
dev.off()

for(i in 1:nrow(finalProfiles)){
	if(sum(geneToPatternCor[,i]>=pearsonCutoff)>0){
		drawData  <- as.matrix(expDataFiltered[geneToPatternCor[,i]>=pearsonCutoff,])
		if(nrow(drawData)==length(drawData)){ # only one gene
			drawData <- t(drawData)		#make the matrix 1 row instead of 1 col. just a hack
		}
		bitmap(file=paste("'.$prefixName.'_pattern_",i,"_geneCurves.png",sep=""),type="png16m",height=4,width=6,res=200)
		par(mfrow=c(1,1),mar=c(11,5,2,1))
		drawGeneGroupCurves(drawData,centerCurve=finalProfiles[i,],title=paste("Pattern ",i," Genes",sep=""))
		dev.off()

		bitmap(file=paste("'.$prefixName.'_pattern_",i,"_geneHeatmap.png",sep=""),type="png16m",height=4,width=6,res=200)
		par(mfrow=c(1,1),mar=c(11,4,2,1))
		drawExpressionHeatmap(drawData,yAxisNames=NA,title=paste("Pattern ",i," Genes",sep=""))
		dev.off()
	}else{
		cat("No genes assigned to pattern ",i," --- Skipping drawing\n")
	}
}




';
return($Rscript);
}

sub generateQFile {
	my ($prefix,$workDir,$options) = @_;

my $qFile = '
#!/bin/tsch
#
#$ -S /bin/bash -cwd
#$ -o '.$prefix.'_cluster.out -j y
'.$options.'


cd '.$workDir.'
/usr/bin/R --no-save < '.$prefix.'_PatternFind_Rcode.r

';
return($qFile);
}


